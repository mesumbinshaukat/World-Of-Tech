<?php 
$conn = mysqli_connect('localhost', 'root', 'cJnc9ZvXnxM9i9', 'world_of_tech') or die("Can't Connect");

if ($conn) {
    $submit_btn = $_POST['btn_submit'];

    if (isset($submit_btn)) {
        $user_name = $_POST['user_name'];
        $user_email = $_POST['user_email'];
        $phone_number = $_POST['phone_number'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];
    }
}


?>