<!DOCTYPE html>
<html lang="en">

<head>
    <title>WORLD OF TECH</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./bootstrap-5.2.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
</head>

<body>

    <section id="navbar">

         <?php # include("navbar.html");?>
        <?php include("navtest.html");?>


    </section>

    <section>
        <main>
            <div class="container-fluid mt-5">
                <center>
                    <div class="row mt-5 text-center justify-content-center">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-5 text-center">
                            <h1 class="text-center mt-5">COMING SOON!!!</h1>
                        </div>
                    

                    </div>
                </center>
            </div>
        </main>
    </section>

    <section id="footer">
        <?php include("footer.php");?>

    </section>
</body>

</html>