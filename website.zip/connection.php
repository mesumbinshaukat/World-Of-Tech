<?php
// $conn = mysqli_connect('localhost', 'root', 'XcRny943ve76JB', 'world_of_tech') or die("Can't Connect");

// $conn = mysqli_connect('localhost', 'root', '', 'world_of_tech') or die("Can't Connect");

$conn = mysqli_connect('localhost', 'root', 'ILoveYouJaveria5Sep!', 'world_of_tech') or die("Can't Connect");




?>